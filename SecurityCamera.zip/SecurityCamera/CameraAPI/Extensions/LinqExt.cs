﻿using System.Collections.Generic;

namespace System.Linq
{
	public static class LinqExt
	{
		public static IEnumerable<IEnumerable<TSource>> GroupByNested<TSource, TKey>(this IEnumerable<TSource> list, Func<TSource, TKey> keySelector)
		{
			var output = list.GroupBy(keySelector).Select(s => s);
			return output;
		}

		public static List<List<TSource>> GroupByNestedList<TSource, TKey>(this IEnumerable<TSource> list, Func<TSource, TKey> keySelector)
		{
			var output = list.GroupBy(keySelector).Select(s => s.ToList()).ToList();
			return output;
		}
	}
}