﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Mvc;
using Camera.Models;
using CameraAPI.Models;
using Newtonsoft.Json;

namespace CameraAPI.Controllers
{
	public class HomeController : Controller
	{
		private string baseurl = "http://localhost:13725/api/Camera";


		public async Task<ActionResult> Index()
		{

			var model = new CameraViewModel();

			model.ColumnNames = new List<CameraColumn>
			{
				new CameraColumn {Id = 1, Name = "3"},
				new CameraColumn {Id = 2, Name = "5"},
				new CameraColumn {Id = 3, Name = "3 & 5"},
				new CameraColumn {Id = 4, Name = "Overig"}
			};


			using (var client = new HttpClient())
			{
				//Passing service base url  
				client.BaseAddress = new Uri(baseurl);

				client.DefaultRequestHeaders.Clear();
				//Define request data format  
				client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

				//Sending request to find web api REST service resource Get using HttpClient  
				var cameras = await client.GetAsync("");

				//Checking the response is successful or not which is sent using HttpClient  
				if (cameras.IsSuccessStatusCode)
				{
					//Storing the response details recieved from web API   
					var response = cameras.Content.ReadAsStringAsync().Result;

					//Deserializing the response recieved from web api and storing into the Camera list  
					model.Cameras = JsonConvert.DeserializeObject<List<CameraModel>>(response);
				}

				return View(model);
			}
		}

		public async Task<ActionResult> Map()
		{

			var model = new MapViewModel();

			using (var client = new HttpClient())
			{
				//Passing service base url  
				client.BaseAddress = new Uri(baseurl);

				client.DefaultRequestHeaders.Clear();
				//Define request data format  
				client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

				//Sending request to find web api REST service resource Get using HttpClient  
				var cameras = await client.GetAsync("");

				//Checking the response is successful or not which is sent using HttpClient  
				if (cameras.IsSuccessStatusCode)
				{
					//Storing the response details recieved from web API   
					var response = cameras.Content.ReadAsStringAsync().Result;

					//Deserializing the response recieved from web api and storing into the Camera list  
					model.Cameras = JsonConvert.DeserializeObject<List<CameraModel>>(response);
				}

				return View(model);
			}

		}
	}
}
