﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using CameraAPI.Models;

namespace CameraAPI.Controllers
{
	public class CameraController : ApiController
	{
		public List<CameraValues> Get()
		{
			string appdatafolder = Path.Combine(HttpContext.Current.Request.PhysicalApplicationPath, "App_Data");
			string path = Path.Combine(appdatafolder, "cameras-defb.csv");
			var cameras = File.ReadAllLines(path).Skip(1).Select(CameraValues.FromCsv).ToList();
			return cameras.OrderBy(x => x.CameraNumber).Skip(1).ToList();
		}

		public CameraValues Get(int id)
		{
			string path = Path.Combine(Environment.CurrentDirectory, @"App_Data\", "cameras-defb.csv");
			var cameras = File.ReadAllLines(path).Skip(1).Select(CameraValues.FromCsv).ToList();
			return cameras.FirstOrDefault(c => c.CameraNumber == id);
		}
	}
}
