﻿using System;

namespace CameraAPI.Models
{

	public class CameraValues
	{
		public string Name;
		public int CameraNumber;
		public decimal Longitude;
		public decimal Latitude;

		public override string ToString()
		{
			return $"{CameraNumber} | {Name} | {Latitude} | {Longitude}";
		}

		public static CameraValues FromCsv(string csvLine)
		{
			if (csvLine.StartsWith("ERROR"))
				return new CameraValues();

			var values = csvLine.Split(';');
			var cameraValues = new CameraValues {

				CameraNumber = GetCameraNumber(values[0]),
				Name = FormatName(values[0]),
				Latitude = Convert.ToDecimal(values[1]),
				Longitude = Convert.ToDecimal(values[2]),
			};
			return cameraValues;
		}


		public static string FormatName(string value)
		{
			return value.Substring(0, 10) + " " + value.Substring(11);
		}

		public static int GetCameraNumber(string value)
		{
			return Convert.ToInt32(value.Substring(7, 3));
		}
	}

}