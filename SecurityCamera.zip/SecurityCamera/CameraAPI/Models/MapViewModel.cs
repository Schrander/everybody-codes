﻿using System.Collections.Generic;

namespace Camera.Models
{
	public class MapViewModel
	{
		public List<CameraModel> Cameras = new List<CameraModel>();
	}
}