﻿using System.Collections.Generic;
using CameraAPI.Models;

namespace Camera.Models
{
	public class CameraViewModel
	{
		public List<CameraModel> Cameras = new List<CameraModel>();
		public List<CameraColumn> ColumnNames = new List<CameraColumn>();
	}
}