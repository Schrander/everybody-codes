﻿namespace CameraAPI.Models
{
	public class CameraColumn
	{
		public int Id { get; set; }
		public string Name { get; set; }
	}
}