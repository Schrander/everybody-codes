﻿namespace Camera.Models
{

	public class CameraModel
	{
		public string Name { get; set; }
		public int CameraNumber { get; set; }
		public decimal Longitude { get; set; }
		public decimal Latitude { get; set; }

		public int Column
		{
			get
			{
				if (CameraNumber % 15 == 0)
					return 3;
				if (CameraNumber % 3 == 0)
					return 1;
				if (CameraNumber % 5 == 0)
					return 2;
				return 4;
			}
		}
	}
}