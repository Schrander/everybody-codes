﻿using System;
using System.IO;
using System.Linq;

namespace NPO_CLI
{

	internal class Program
	{
		private static void Main(string[] args)
		{

			var searchField = args[0];
			var searchValue = args[1];

			if (searchField != "--name")
				Console.WriteLine("Invalid parameter supplied.");
			else
			{
				string path = Path.Combine(Environment.CurrentDirectory, @"data\", "cameras-defb.csv");
				var cameras = File.ReadAllLines(path).Skip(1).Select(CameraValues.FromCsv).ToList();

				var filtering = cameras.Where(w => w.Name.Contains(searchValue, StringComparison.OrdinalIgnoreCase)).ToList();
				foreach (var camera in filtering)
				{
					Console.WriteLine(camera);
				}
			}
			Console.ReadLine();
		}
	}


	public static class StringExtensions
	{
		public static bool Contains(this string source, string toCheck, StringComparison comparison)
		{
			return source?.IndexOf(toCheck, comparison) >= 0;
		}
	}

	public class CameraValues
	{
		public string Name;
		public int CameraNumber;
		public decimal Longitude;
		public decimal Latitude;

		public override string ToString()
		{
			return $"{CameraNumber} | {Name} | {Latitude} | {Longitude}";
		}

		public static CameraValues FromCsv(string csvLine)
		{
			if (csvLine.StartsWith("ERROR"))
				return new CameraValues();

			var values = csvLine.Split(';');
			var cameraValues = new CameraValues {

				CameraNumber = GetCameraNumber(values[0]),
				Name = FormatName(values[0]),
				Latitude = Convert.ToDecimal(values[1]),
				Longitude = Convert.ToDecimal(values[2]),
			};
			return cameraValues;
		}


		public static string FormatName(string value)
		{
			return value.Substring(0, 10) + " " + value.Substring(11);
		}

		public static int GetCameraNumber(string value)
		{
			return Convert.ToInt32(value.Substring(7, 3));
		}
	}

}